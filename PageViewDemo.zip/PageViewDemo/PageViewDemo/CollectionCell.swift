//
//  CollectionCell.swift
//  VideoPlayer
//
//  Created by Mandeep Singh on 07/07/19.
//  Copyright © 2019 Mandeep Singh. All rights reserved.
//

import UIKit
import AVFoundation

protocol PlayerStatusDelegate {
    func playerReadyToPlay(url: URL)
}

class CollectionCell: UICollectionViewCell {
    @IBOutlet weak var cellImageView: UIImageView!

    var avPlayer : AVPlayer = AVPlayer()
    fileprivate var avPlayerLayer : AVPlayerLayer!
    var currentVideoUrl: String = ""
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let videoURL = URL(string: currentVideoUrl )
        if videoURL != nil {
            self.avPlayer = AVPlayer(url: videoURL!)
            
            self.avPlayerLayer = AVPlayerLayer(player: self.avPlayer)
            self.avPlayerLayer.frame = self.contentView.bounds
            self.avPlayerLayer.videoGravity = .resize
            self.contentView.layer.sublayers?.removeAll()
            self.contentView.layer.insertSublayer(self.avPlayerLayer, at: 0)
            self.avPlayer.play()
            
            //self.zeeOriginalImg.isHidden = true
            
            self.cellImageView.isHidden = false
            
            self.layoutIfNeeded()
        }
        
    }
    
    
   func playerReadyToPlay(url: URL) {
       
               if self.currentVideoUrl.count > 0 {
                   self.play()
               }
           }
    
    
    func play() {
        if VideoPlayerHandler.shared.didSelected == false {
            VideoPlayerHandler.shared.queuePlayer?.play()
        }
    }

    
    deinit {
        print("deinit collectionviw cell")
    }

}
