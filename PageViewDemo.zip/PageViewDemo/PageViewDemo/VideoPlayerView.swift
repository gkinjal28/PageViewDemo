//
//  VideoPlayerView.swift
//  KD Tiktok-Clone
//
//  Created by Sam Ding on 9/24/20.
//  Copyright © 2020 Kaishan. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation

class VideoPlayerView: UIView {
    
    // MARK: - Variables

    var avPlayerLayer: AVPlayerLayer!
    var playerDelegate: PlayerStatusDelegate?
        
    
    // MARK: - Initializers
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        VideoPlayerHandler.shared.removeObserver()
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        backgroundColor = .clear
        print("________Layer_Bounds:\(self.layer.bounds)")
        avPlayerLayer.frame = self.layer.bounds
    }
    
    func setupView(){
        
        VideoPlayerHandler.shared.setupPlayer()
        avPlayerLayer = AVPlayerLayer(player: VideoPlayerHandler.shared.queuePlayer)
        avPlayerLayer.frame = self.layer.bounds
        avPlayerLayer.videoGravity = .resizeAspect
        self.layer.addSublayer(self.avPlayerLayer)
    }
    
    func configure(url: URL?, fileExtension: String?){
        VideoPlayerHandler.shared.stopVideoPlayer()
        guard let url = url else {
            print("URL Error from Tableview Cell")
            return
        }
        VideoPlayerHandler.shared.fileExtension = fileExtension
        VideoPlayerHandler.shared.originalURL = url
        VideoPlayerHandler.shared.asset = AVURLAsset(url: VideoPlayerHandler.shared.originalURL!)
        VideoPlayerHandler.shared.asset!.resourceLoader.setDelegate(self, queue: .main)
        
        if VideoPlayerHandler.shared.playerItem == nil {
            VideoPlayerHandler.shared.playerItem = AVPlayerItem(asset: VideoPlayerHandler.shared.asset!)
            self.addObserverToPlayerItem(url: url)
            
            if let queuePlayer = VideoPlayerHandler.shared.queuePlayer {
                queuePlayer.replaceCurrentItem(with: VideoPlayerHandler.shared.playerItem)
            } else {
                VideoPlayerHandler.shared.queuePlayer = AVQueuePlayer(playerItem: VideoPlayerHandler.shared.playerItem)
            }
            
            self.avPlayerLayer.player = VideoPlayerHandler.shared.queuePlayer
        }else {
            VideoPlayerHandler.shared.stopVideoPlayer()
        }
        
      
    }
    
    /// Clear all remote or local request
    func cancelAllLoadingRequest(){
        avPlayerLayer.player = nil
        playerDelegate = nil
        VideoPlayerHandler.shared.stopVideoPlayer()
    }
    
    
    func replay(){
        VideoPlayerHandler.shared.queuePlayer?.seek(to: .zero)
        play()
    }
    
    func play() {
        print("Player to play")
        if VideoPlayerHandler.shared.didSelected == false {
            VideoPlayerHandler.shared.queuePlayer?.play()
        }
    }
    
    func pause(){
        VideoPlayerHandler.shared.queuePlayer?.pause()
    }
    
    func addObserverToPlayerItem(url: URL) {
        // Register as an observer of the player item's status property
        VideoPlayerHandler.shared.observer = VideoPlayerHandler.shared.playerItem!.observe(\.status, options: [.initial, .new], changeHandler: { [self] item, _ in
            let status = item.status
            // Switch over the status
            switch status {
            case .readyToPlay:
                // Player item is ready to play.
                print("Status: addObserverToPlayerItem readyToPlay")
                VideoPlayerHandler.shared.playerStatus = .readyToPlay
                
                if VideoPlayerHandler.shared.didSelected == false{
                    playerDelegate?.playerReadyToPlay(url: url)
                }
            case .failed:
                // Player item failed. See error.
                print("Status: addObserverToPlayerItem failed Error: " + item.error!.localizedDescription )
                VideoPlayerHandler.shared.playerStatus = .failed
               // self.pause()
            case .unknown:
                // Player item is not yet ready.bn m
                print("Status: addObserverToPlayerItem unknown")
                VideoPlayerHandler.shared.playerStatus = .unknown
                //self.pause()
            @unknown default:
                fatalError("Status addObserverToPlayerItem is not yet ready to present")
                //self.pause()
            }
        })
    }
    
}

// MARK: - KVO
extension VideoPlayerHandler {
    func removeObserver() {
        if let observer = observer {
            observer.invalidate()
        }
    }
  
}

// MARK: - URL Session Delegate
extension VideoPlayerHandler: URLSessionTaskDelegate, URLSessionDataDelegate {
    // Get Responses From URL Request
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        self.infoResponse = response
        self.processLoadingRequest()
        completionHandler(.allow)
    }
    
    // Receive Data From Responses and Download
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        self.videoData?.append(data)
        self.processLoadingRequest()
    }
    
    // Responses Download Completed
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let error = error {
            print("AVURLAsset Download Data Error: " + error.localizedDescription)
        } else {
          //  VideoCacheManager.shared.storeDataToCache(data: self.videoData, key: self.originalURL!.absoluteString, fileExtension: self.fileExtension)
        }
    }
    
    private func processLoadingRequest(){
        var finishedRequests = Set<AVAssetResourceLoadingRequest>()
        self.loadingRequests.forEach {
            var request = $0
            if self.isInfo(request: request), let response = self.infoResponse {
                self.fillInfoRequest(request: &request, response: response)
            }
            if let dataRequest = request.dataRequest, self.checkAndRespond(forRequest: dataRequest) {
                finishedRequests.insert(request)
                request.finishLoading()
            }
        }
        self.loadingRequests = self.loadingRequests.filter { !finishedRequests.contains($0) }
    }
    
    private func fillInfoRequest(request: inout AVAssetResourceLoadingRequest, response: URLResponse) {
        request.contentInformationRequest?.isByteRangeAccessSupported = true
        request.contentInformationRequest?.contentType = response.mimeType
        request.contentInformationRequest?.contentLength = response.expectedContentLength
    }
    
    private func isInfo(request: AVAssetResourceLoadingRequest) -> Bool {
         return request.contentInformationRequest != nil
     }
    
    private func checkAndRespond(forRequest dataRequest: AVAssetResourceLoadingDataRequest) -> Bool {
        guard let videoData = videoData else { return false }
        let downloadedData = videoData
        let downloadedDataLength = Int64(downloadedData.count)
        let requestRequestedOffset = dataRequest.requestedOffset
        let requestRequestedLength = Int64(dataRequest.requestedLength)
        let requestCurrentOffset = dataRequest.currentOffset
        if downloadedDataLength < requestCurrentOffset {
            return false
        }
        let downloadedUnreadDataLength = downloadedDataLength - requestCurrentOffset
        let requestUnreadDataLength = requestRequestedOffset + requestRequestedLength - requestCurrentOffset
        let respondDataLength = min(requestUnreadDataLength, downloadedUnreadDataLength)

        dataRequest.respond(with: downloadedData.subdata(in: Range(NSMakeRange(Int(requestCurrentOffset), Int(respondDataLength)))!))

        let requestEndOffset = requestRequestedOffset + requestRequestedLength

        return requestCurrentOffset >= requestEndOffset

    }
}

// MARK: - AVAssetResourceLoader Delegate
extension VideoPlayerView: AVAssetResourceLoaderDelegate {
    func resourceLoader(_ resourceLoader: AVAssetResourceLoader, shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest) -> Bool {
        if VideoPlayerHandler.shared.task == nil, let url = VideoPlayerHandler.shared.originalURL {
            let request = URLRequest.init(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
            VideoPlayerHandler.shared.task = VideoPlayerHandler.shared.session?.dataTask(with: request)
            VideoPlayerHandler.shared.task?.resume()
        }
        VideoPlayerHandler.shared.loadingRequests.append(loadingRequest)
        return true
    }

    func resourceLoader(_ resourceLoader: AVAssetResourceLoader, didCancel loadingRequest: AVAssetResourceLoadingRequest) {
        if let index = VideoPlayerHandler.shared.loadingRequests.firstIndex(of: loadingRequest) {
            VideoPlayerHandler.shared.loadingRequests.remove(at: index)
        }
    }
}



extension URL {
    /// Adds the scheme prefix to a copy of the receiver.
    func convertToRedirectURL(scheme: String) -> URL? {
        var components = URLComponents.init(url: self, resolvingAgainstBaseURL: false)
        let schemeCopy = components?.scheme ?? ""
        components?.scheme = schemeCopy + scheme
        return components?.url
    }
    
    /// Removes the scheme prefix from a copy of the receiver.
    func convertFromRedirectURL(prefix: String) -> URL? {
        guard var comps = URLComponents(url: self, resolvingAgainstBaseURL: false) else {return nil}
        guard let scheme = comps.scheme else {return nil}
        comps.scheme = scheme.replacingOccurrences(of: prefix, with: "")
        return comps.url
    }
}



final class VideoPlayerHandler: NSObject {
    static let shared = VideoPlayerHandler()
    private override init() {
        super.init()
    }
    
    var videoURL: URL?
    var originalURL: URL?
    
    var asset: AVURLAsset?
    var playerItem: AVPlayerItem?
    var queuePlayer: AVQueuePlayer?
    var observer: NSKeyValueObservation?
    var videoData: Data?
    var fileExtension: String?
    var session: URLSession?
    var loadingRequests = [AVAssetResourceLoadingRequest]()
    var task: URLSessionDataTask?
    var infoResponse: URLResponse?
    var cancelLoadingQueue: DispatchQueue?
    var playerStatus: AVPlayerItem.Status = .unknown
    var didSelected: Bool = false
    func setupPlayer(){
        let operationQueue = OperationQueue()
        operationQueue.name = "com.VideoPlayer.URLSeesion"
        operationQueue.maxConcurrentOperationCount = 1
        session = URLSession.init(configuration: .default, delegate: self, delegateQueue: operationQueue)
        cancelLoadingQueue = DispatchQueue.init(label: "com.cancelLoadingQueue")
        videoData = Data()
    }
    
    func stopVideoPlayer(){
        self.queuePlayer?.replaceCurrentItem(with: nil)
        self.queuePlayer = nil
        self.removeObserver()
        self.videoURL = nil
        self.originalURL = nil
        self.asset = nil
        self.playerItem = nil
        self.cancelLoadingQueue?.async {
            self.session?.invalidateAndCancel()
            self.session = nil
            self.asset?.cancelLoading()
            self.task?.cancel()
            self.task = nil
            self.videoData = nil
            self.loadingRequests.forEach { $0.finishLoading() }
            self.loadingRequests.removeAll()
        }
    }
    
    func pause(){
        self.queuePlayer?.pause()
    }

}
